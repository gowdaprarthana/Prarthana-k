import json
import os
from collections import defaultdict
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd
import requests
import streamlit as st
# 🚫 Removed: import sseclient

from models import (
    ChartEventData,
    DataAgentRunRequest,
    ErrorEventData,
    Message,
    MessageContentItem,
    StatusEventData,
    TableEventData,
    TextContentItem,
    TextDeltaEventData,
    ThinkingDeltaEventData,
    ThinkingEventData,
    ToolResultEventData,
    ToolUseEventData,
)
PAT ="eyJraWQiOiI0Njg1MzQxNDkzNyIsImFsZyI6IkVTMjU2In0.eyJwIjoiMTgzMDIxMDYwOjE4MzAyMTE4OCIsImlzcyI6IlNGOjEwMjMiLCJleHAiOjE3OTE5MDA5OTl9.hQWzCvoCYxQhov6E4WzrGhudVZgYENqSEvwyPszvQW3EOhmOOIk6FtO-VWrv25fE_odcQO1ZWBzEAveM2KvQdw"
HOST = "YXEHTDP-AC89486.snowflakecomputing.com"
DATABASE = os.getenv("CORTEX_AGENT_DEMO_DATABASE", "SNOWFLAKE_INTELLIGENCE")
SCHEMA = os.getenv("CORTEX_AGENT_DEMO_SCHEMA", "AGENTS")
AGENT = os.getenv("CORTEX_AGENT_DEMO_AGENT", "IDEA_SF_AGENT")

# Optional: allow toggling SSL verification via env
VERIFY_SSL = os.getenv("VERIFY_SSL", "true").lower() == "true"

# ------------------------------------------------------------------------------
# Minimal SSE support (no third-party sseclient needed)
# ------------------------------------------------------------------------------

@dataclass
class SSEEvent:
    """Represents a single Server-Sent Event."""
    event: str = "message"
    data: str = ""
    id: Optional[str] = None

def iter_sse_events(resp: requests.Response):
    """
    Iterate Server-Sent Events (SSE) from a streaming HTTP response.
    - Expects the server to send text/event-stream content.
    - Parses 'event:', 'data:' (possibly multi-line), and 'id:' fields.
    - Yields SSEEvent objects on blank-line delimiters.
    """
    resp.raise_for_status()

    # Basic sanity: not strictly required, but helpful for debugging.
    # Some proxies omit this header even for SSE, so don't hard-fail.
    ctype = resp.headers.get("Content-Type", "")
    if "text/event-stream" not in ctype.lower():
        # It's still fine to proceed; many servers omit or vary content-type.
        pass

    event_type = "message"
    event_id = None
    data_lines = []

    # decode_unicode=True yields str. iter_lines preserves event boundaries with blank lines.
    for raw in resp.iter_lines(decode_unicode=True):
        if raw is None:
            continue
        line = raw.rstrip("\n")

        # Empty line indicates the end of one SSE event message.
        if line == "":
            if data_lines:
                yield SSEEvent(
                    event=event_type or "message",
                    data="\n".join(data_lines),
                    id=event_id,
                )
            # Reset buffers for the next event
            event_type = "message"
            event_id = None
            data_lines = []
            continue

        # Comment lines (ignored)
        if line.startswith(":"):
            continue

        if line.startswith("event:"):
            event_type = line[len("event:"):].strip()
        elif line.startswith("data:"):
            # Allow leading space after 'data:'
            data_lines.append(line[len("data:"):].lstrip())
        elif line.startswith("id:"):
            event_id = line[len("id:"):].strip()
        # Optional: 'retry:' not needed for client-side logic here.

    # Flush any trailing event if the stream ended without a final blank line
    if data_lines:
        yield SSEEvent(
            event=event_type or "message",
            data="\n".join(data_lines),
            id=event_id,
        )

# ------------------------------------------------------------------------------
# REST call to Snowflake Cortex Agent :run endpoint (POST + streaming)
# ------------------------------------------------------------------------------

def agent_run() -> requests.Response:
    """Calls the REST API and returns a streaming Response for SSE."""
    if not PAT:
        raise RuntimeError(
            "SNOWFLAKE_PAT is not set. Please set the environment variable with your PAT."
        )

    request_body = DataAgentRunRequest(
        model="claude-4-sonnet",
        messages=st.session_state.messages,
    )

    # Use json= so requests sets content-type and encodes properly
    payload = json.loads(request_body.to_json())

    resp = requests.post(
url=f"https://{HOST}/api/v2/databases/{DATABASE}/schemas/{SCHEMA}/agents/{AGENT}:run",
        json=payload,      
        headers={
            "Authorization": f"Bearer {PAT}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
        stream=True,      # 🔴 critical for SSE
        verify=VERIFY_SSL
    )
    if resp.status_code < 400:
        return resp
    else:
        raise Exception(f"Failed request with status {resp.status_code}: {resp.text}")

# ------------------------------------------------------------------------------
# Stream SSE events and render in Streamlit
# ------------------------------------------------------------------------------

def stream_events(response: requests.Response):
    content = st.container()
    content_map = defaultdict(content.empty)  # lazily creates placeholders per content index
    buffers = defaultdict(str)

    spinner = st.spinner("Waiting for response...")
    spinner.__enter__()

    try:
        # Use our minimal SSE iterator over the Response
        with response:
            for event in iter_sse_events(response):
                match event.event:
                    case "response.status":
                        spinner.__exit__(None, None, None)
                        data = StatusEventData.from_json(event.data)
                        spinner = st.spinner(data.message)
                        spinner.__enter__()
                    case "response.text.delta":
                        data = TextDeltaEventData.from_json(event.data)
                        buffers[data.content_index] += data.text
                        content_map[data.content_index].write(buffers[data.content_index])
                    case "response.thinking.delta":
                        data = ThinkingDeltaEventData.from_json(event.data)
                        buffers[data.content_index] += data.text
                        content_map[data.content_index].expander("Thinking", expanded=True).write(
                            buffers[data.content_index]
                        )
                    case "response.thinking":
                        data = ThinkingEventData.from_json(event.data)
                        content_map[data.content_index].expander("Thinking").write(data.text)
                    case "response.tool_use":
                        data = ToolUseEventData.from_json(event.data)
                        content_map[data.content_index].expander("Tool use").json(data)
                    case "response.tool_result":
                        data = ToolResultEventData.from_json(event.data)
                        content_map[data.content_index].expander("Tool result").json(data)
                    case "response.chart":
                        data = ChartEventData.from_json(event.data)
                        spec = json.loads(data.chart_spec)
                        content_map[data.content_index].vega_lite_chart(spec, use_container_width=True)
                    case "response.table":
                        data = TableEventData.from_json(event.data)
                        data_array = np.array(data.result_set.data)
                        column_names = [col.name for col in data.result_set.result_set_meta_data.row_type]
                        df = pd.DataFrame(data_array, columns=column_names)
                        content_map[data.content_index].dataframe(df)
                    case "error":
                        data = ErrorEventData.from_json(event.data)
                        st.error(f"Error: {data.message} (code: {data.code})")
                        # Rollback the last user message since it failed
                        if st.session_state.messages and st.session_state.messages[-1].role == "user":
                            st.session_state.messages.pop()
                        return
                    case "response":
                        data = Message.from_json(event.data)
                        st.session_state.messages.append(data)
                    case _:
                        # Unknown/aux events: optional debug
                        # st.write(f"Unknown event type: {event.event} data: {event.data}")
                        pass
    finally:
        spinner.__exit__(None, None, None)

# ------------------------------------------------------------------------------
# Streamlit orchestration
# ------------------------------------------------------------------------------

def process_new_message(prompt: str) -> None:
    message = Message(
        role="user",
        content=[MessageContentItem(TextContentItem(type="text", text=prompt))],
    )
    render_message(message)
    st.session_state.messages.append(message)

    with st.chat_message("assistant"):
        with st.spinner("Sending request..."):
            response = agent_run()
        st.markdown(f"```request_id: {response.headers.get('X-Snowflake-Request-Id')}```")
        stream_events(response)

def render_message(msg: Message):
    with st.chat_message(msg.role):
        for content_item in msg.content:
            match content_item.actual_instance.type:
                case "text":
                    st.markdown(content_item.actual_instance.text)
                case "chart":
                    spec = json.loads(content_item.actual_instance.chart.chart_spec)
                    st.vega_lite_chart(spec, use_container_width=True)
                case "table":
                    data_array = np.array(content_item.actual_instance.table.result_set.data)
                    column_names = [
                        col.name for col in content_item.actual_instance.table.result_set.result_set_meta_data.row_type
                    ]
                    st.dataframe(pd.DataFrame(data_array, columns=column_names))
                case _:
                    st.expander(content_item.actual_instance.type).json(
                        content_item.actual_instance.to_json()
                    )

# ------------------------------------------------------------------------------
# Streamlit UI
# ------------------------------------------------------------------------------

st.title("Cortex Agent")

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    render_message(message)

if user_input := st.chat_input("What is your question?"):
    process_new_message(prompt=user_input)